package com.divi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiviApplicationTests {

	@Test
	void contextLoads() {
	}

}
